
# SA-MP Android

An **SA-MP (San Andreas Multiplayer) client** for Android — bring the classic GTA:SA multiplayer experience to your mobile device.

[![GitHub Release](https://img.shields.io/github/v/release/SA-MP-Android/App)](https://github.com/SA-MP-Android/App/releases)
[![GitHub Downloads](https://img.shields.io/github/downloads/SA-MP-Android/App/total)](https://github.com/SA-MP-Android/App/releases)

## Screenshots

| Launcher | Settings |
|:---:|:---:|
| ![Home](assets/home.jpg) | ![Settings](assets/settings.jpg) |

| Gameplay | TAB Menu |
|:---:|:---:|
| ![In-Game](assets/in_game.jpg) | ![TAB](assets/in_game_tab.jpg) |

| RakSAMP Chat | RakSAMP Players |
|:---:|:---:|
| ![Chat](assets/raksamp_chat.jpg) | ![Players](assets/raksamp_players.jpg) |

## Features

- **Full SA-MP client** — connect to any SA-MP server, play with full chat, TAB player list, dialogs
- **Dual ABI** — supports both 32-bit (`armeabi-v7a`) and 64-bit (`arm64-v8a`) devices
- **Modern UI** — Material 3 launcher, traditional Android Views for in-game overlays
- **Native in-game widgets** — quick action buttons, passenger/copilot entry, HUD toggles
- **Crash resilience** — dual-signal render protection for stability
- **Multilingual** — English, Simplified Chinese, Russian

## Requirements

- **Android 8.0+** (API 26)
- **2+ GB RAM** recommended

> [!IMPORTANT]
> This app loads the GTA:SA engine (`libGTASA.so`) at runtime. It does **not** include game files.

## Download

Get the latest APK from the [Releases](https://github.com/SA-MP-Android/App/releases) page.

| APK | Architecture |
|:---|:---|
| `app-arm64-v8a-release.apk` | 64-bit devices |
| `app-armeabi-v7a-release.apk` | 32-bit devices |
| `app-universal-release.apk` | Both (larger size) |

---

*SA-MP Android is not affiliated with Rockstar Games, Take-Two Interactive, or the SA-MP team. GTA:SA is a trademark of Rockstar Games.*
